const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const core=require('../src/core.js');
const zip=require('../src/zip.js');
const src=fs.readFileSync(require('node:path').join(__dirname,'../src/content.js'),'utf8');
function harness(messages=[]){
  let listener;const store={};
  const chrome={runtime:{id:'extension-test',onMessage:{addListener(fn){listener=fn;}}},storage:{local:{
    async get(key){return {[key]:store[key]};},async set(values){Object.assign(store,values);},async remove(key){delete store[key];}
  }}};
  const location={hostname:'chatgpt.com',protocol:'https:',pathname:'/c/12345678-1234',href:'https://chatgpt.com/c/12345678-1234'};
  const context={chrome,location,ChatArchiveCore:{...core,extractMessages:()=>messages},ChatArchiveZip:zip,document:{querySelectorAll:()=>[]},setTimeout,clearTimeout,Date,Promise,console,globalThis:null};
  context.globalThis=context;
  vm.runInNewContext(src,context,{timeout:2000});
  const send=(type,sender={id:'extension-test',url:'chrome-extension://extension-test/popup.html'},extra={})=>new Promise((resolve,reject)=>{
    const accepted=listener({type,...extra},sender,x=>resolve(x));
    if(accepted!==true)resolve({rejected:true});
  });
  return {send,store,listener};
}
test('messages are accepted only from the extension popup',async()=>{
  const h=harness();
  const invalid=await h.send('START_A',{id:'extension-test',url:'https://malicious.example/'},{operation:'manual'});
  assert.deepEqual(invalid,{rejected:true});
  const nonPopup=await h.send('START_A',{id:'extension-test',url:'chrome-extension://extension-test/docs/help.html'},{operation:'manual'});
  assert.deepEqual(nonPopup,{rejected:true});
  const valid=await h.send('PING');
  assert.equal(valid.ok,true);
  assert.equal(valid.data.conversation,'12345678-1234');
  assert.deepEqual(Object.keys(h.store),[]);
});
test('manual A creates six persistent categories without sending a message',async()=>{
  const h=harness();
  const start=await h.send('START_A',undefined,{operation:'manual'});
  assert.equal(start.ok,true);
  const stored=h.store['archive_v1_A_12345678-1234'];
  assert.equal(stored.mode,'A');
  assert.equal(stored.operation,'manual');
  assert.equal(stored.results.length,6);
  assert.ok(stored.results.every(x=>x===null));
  const stat=await h.send('GET_STATUS');
  assert.equal(stat.data.aJob.completed,0);
  const clear=await h.send('CLEAR_A');
  assert.equal(clear.ok,true);
  assert.equal(Object.keys(h.store).length,0);
});

test('manual A correctly associates a posted prompt with its following assistant answer',async()=>{
  const messages=[{role:'user',text:'【对话归档任务 A1/6：角色设定】',id:'u1'},{role:'assistant',text:'# 角色设定\n这是完整的有效人物设定，并且能够保留详细资料。',id:'a1'}];
  const h=harness(messages);
  await h.send('START_A',undefined,{operation:'manual'});
  const result=await h.send('COLLECT_A');
  assert.equal(result.ok,true);
  assert.equal(result.data.step,1);
  assert.equal(h.store['archive_v1_A_12345678-1234'].results[0],messages[1].text);
  assert.equal(h.store['archive_v1_A_12345678-1234'].results[1],null);
});
