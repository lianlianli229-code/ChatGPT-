const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const core=require('../src/core.js');
const zip=require('../src/zip.js');
const root=path.join(__dirname,'..');
test('six distinct A prompts use precise markers and categories',()=>{
  assert.equal(core.CATEGORIES.length,6);
  for(let i=0;i<6;i++){
    const p=core.promptA(i);
    assert.ok(p.includes(`【对话归档任务 A${i+1}/6：`));
    assert.ok(p.includes(core.CATEGORIES[i][0]));
  }
  assert.throws(()=>core.promptA(6));
});
test('HTML sanitizer forbids scriptable URLs',()=>{
  assert.equal(core.safeUrl('javascript:alert(1)'),'');
  assert.equal(core.safeUrl('data:text/html,<script>'),'');
  assert.equal(core.safeUrl('https://example.org/test?token=secret'),'https://example.org/test');
  assert.equal(core.esc('<b onmouseover="x">'), '&lt;b onmouseover=&quot;x&quot;&gt;');
});
test('A file combines exactly six sections in one document',()=>{
  const md=core.combinedMarkdown(['A','B','C','D','E','F'],'A','测试');
  assert.equal((md.match(/^## [1-6]、/gm)||[]).length,6);
  assert.ok(md.includes('## 6、历史图片信息'));
});
test('B uses each chunk once to request all six sections',()=>{
  const prompt=core.promptB('原始消息',1,3);
  assert.ok(prompt.includes('[SECTION:1]'));
  assert.ok(prompt.includes('[SECTION:6]'));
  assert.ok(prompt.includes('原始消息'));
  const parsed=core.parseBSections('[SECTION:1]a\n[SECTION:2]b\n[SECTION:3]c\n[SECTION:4]d\n[SECTION:5]e\n[SECTION:6]f');
  assert.ok(parsed.complete);
  assert.deepEqual(parsed.parts.map(x=>x.trim()),['a','b','c','d','e','f']);
});
test('chunking never drops an oversized single message',()=>{
  const data=[{role:'user',id:'X',text:'哈'.repeat(4400)}];
  const chunks=core.splitIntoChunks(data,1200);
  assert.ok(chunks.length>=4);
  assert.ok(chunks.every(c=>c.signature));
  assert.ok(chunks.map(c=>c.text).join('').includes('哈'.repeat(500)));
});
test('merge preserves old messages while adding visible older page messages',()=>{
  const m=id=>({id});
  let result=core.mergeMessages([m('c'),m('d')],[m('a'),m('b'),m('c')]);
  assert.deepEqual(result.messages.map(x=>x.id),['a','b','c','d']);
  result=core.mergeMessages(result.messages,[m('b'),m('c'),m('d')]);
  assert.deepEqual(result.messages.map(x=>x.id),['a','b','c','d']);
});
test('offline HTML is CSP restricted and escapes imported text',()=>{
  const html=core.archiveHtml([{role:'assistant',turnId:'<x>',html:'<p>&lt;script&gt;</p>',text:'script'}],'My <title>',{},{});
  assert.ok(html.includes("default-src 'none'"));
  assert.ok(html.includes('My &lt;title&gt;'));
  assert.ok(!html.includes('https://assets'));
});
test('ZIP rejects traversal and stores each filename',async()=>{
  assert.throws(()=>zip.build([{name:'../../secret',data:'x'}]));
  assert.throws(()=>zip.build([{name:'a//b',data:'x'}]));
  assert.throws(()=>zip.build([{name:'a',data:'x'},{name:'a',data:'y'}]));
  const blob=zip.build([{name:'conversation.html',data:'你好！'},{name:'目录/文件.md',data:'# 测试'}]);
  const bytes=Buffer.from(await blob.arrayBuffer());
  assert.equal(bytes.readUInt32LE(0),0x04034b50);
  fs.writeFileSync(path.join(require('node:os').tmpdir(),'chatarchive-zip-test.zip'),bytes);
});
test('manifest has least-privilege permissions and no host grants',()=>{
  const m=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));
  assert.equal(m.manifest_version,3);
  assert.deepEqual(m.permissions.slice().sort(),['activeTab','scripting','storage'].sort());
  assert.ok(!('host_permissions' in m));
  assert.ok(!('optional_host_permissions' in m));
  assert.ok(m.content_security_policy.extension_pages.includes("script-src 'self'"));
});
test('DOM content extraction keeps roles and strips executable HTML',()=>{
  function T(value){return {nodeType:3,textContent:value,parentElement:null};}
  function E(tag,attrs={},nodes=[]){
    const node={nodeType:1,tagName:tag.toUpperCase(),attrs,childNodes:nodes,parentElement:null,
      getAttribute(name){return this.attrs[name]??null;},
      get textContent(){return this.childNodes.map(x=>x.textContent).join('');},
      get children(){return this.childNodes.filter(x=>x.nodeType===1);},
      closest(selector){let cur=this;while(cur){if(selector==='[data-message-author-role]' && cur.attrs?.['data-message-author-role'])return cur;if(selector==='[data-message-id]'&&cur.attrs?.['data-message-id'])return cur;if(selector==='[data-testid^="conversation-turn-"]'&&cur.attrs?.['data-testid']?.startsWith('conversation-turn-'))return cur;cur=cur.parentElement;}return null;},
      querySelectorAll(selector){const found=[];function visit(n){if(n.nodeType!==1)return;const match=(selector==='img'&&n.tagName==='IMG')||(selector==='[data-message-author-role]'&&n.attrs['data-message-author-role'])||(selector==='[data-message-content], .markdown, .prose' && (n.attrs['class']||'').split(' ').some(x=>['prose','markdown'].includes(x)))||(selector==='[data-testid^="conversation-turn-"]'&&n.attrs['data-testid']?.startsWith('conversation-turn-'));if(match)found.push(n);for(const c of n.childNodes)visit(c);}for(const c of this.childNodes)visit(c);return found;},
      querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
    };for(const child of nodes)child.parentElement=node;return node;
  }
  const user=E('div',{'data-message-author-role':'user'},[E('div',{'class':'prose'},[E('p',{},[T('图片请参考原图')]),E('img',{'alt':'上传图片','src':'https://example.com/im.png?sig=secret'})])]);
  const assistant=E('div',{'data-message-author-role':'assistant'},[E('div',{'class':'markdown'},[E('p',{},[T('请勿'),E('strong',{},[T('泄露密钥')])]),E('a',{'href':'javascript:alert(1)'},[T('XSS')]),E('script',{},[T('alert(1)')])])]);
  const doc=E('main',{},[E('article',{'data-testid':'conversation-turn-0'},[user]),E('article',{'data-testid':'conversation-turn-1'},[assistant])]);
  const messages=core.extractMessages(doc);
  assert.equal(messages.length,2);
  assert.equal(messages[0].role,'user');
  assert.equal(messages[1].role,'assistant');
  assert.equal(messages[0].images[0].displayUrl,'https://example.com/im.png');
  assert.ok(messages[0].html.includes('data-image-key='));
  assert.ok(!messages[1].html.includes('javascript:'));
  assert.ok(!messages[1].html.includes('<script'));
  assert.ok(!messages[1].html.includes('alert(1)'));
  assert.ok(messages[1].text.includes('**泄露密钥**'));
  assert.equal(user.childNodes[0].childNodes[1].getAttribute('data-archive-image-key'),null);
});
