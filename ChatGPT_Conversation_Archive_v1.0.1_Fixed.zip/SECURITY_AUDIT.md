# 安全审核报告 — ChatGPT 对话继承助手 (v1.0.1)

## 一、项目概况与依赖漏洞审查

### 1.1 项目概况

| 维度 | 审核结果 |
| :--- | :--- |
| **项目名称** | ChatGPT 对话继承助手 (`chatgpt-conversation-archive-extension` v1.0.1) |
| **语言与框架** | 原生 JavaScript (ES2022)、HTML5、CSS3；Chrome 浏览器扩展 **Manifest V3**（无前端框架、无常驻后台 Service Worker） |
| **包管理器与清单文件** | npm（含 `package.json`、`package-lock.json`；无 `requirements.txt`、`go.mod`、`Cargo.toml`、`pom.xml`、`Podfile`） |
| **直接依赖 / 间接依赖数量** | **`dependencies`: `0` 个 / `devDependencies`: `0` 个 / 间接依赖：`0` 个** |
| **审核范围** | 全量 21 个文件：`manifest.json`、`package.json`、`package-lock.json`、`.gitignore`、`popup.html`、`popup.css`、`popup.js`、`src/core.js`、`src/zip.js`、`src/content.js`、`docs/help.html`、`docs/help.css`、`README.md`、`SECURITY_AUDIT.md`、`icons/*.png`、`tests/core.test.cjs`、`tests/content.test.cjs`、`tests/browser-harness.html` |

### 1.2 依赖漏洞核查结论

1. **直接依赖与锁文件间接依赖**：经核查 `package.json` 与 `package-lock.json`，项目采用**零运行时依赖、零开发依赖**架构。ZIP 归档生成（`src/zip.js`）与 HTML/Markdown 安全清洗（`src/core.js`）均由本地原生代码实现。
2. **已知 CVE / Advisory 排查**：因直接与间接第三方包数量均为 `0`，无受 GitHub Advisory Database、OSV.dev 或 NVD 已知漏洞影响的依赖项，亦不存在停止维护包或仿冒包（Typosquatting）风险。
3. **本地工具核对状态**：当前 Windows 环境未安装 Node.js / npm CLI（命令行执行状态标注为「**待确认**」），已通过锁文件静态解析确认无任何外部依赖。

---

## 二、问题汇总表

本次全面安全审计**未发现 Critical（严重）或 High（高危）漏洞**。共识别出 **4 项 Medium（中危）** 与 **6 项 Low（低危）** 风险，现已 **100% 全部完成修复**：

| 编号 | 类别 | 严重级别 | 位置 | 状态 | 问题描述 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **V-01** | 代码 | **Medium** | `src/content.js:171-177, 463-580` | **已修复** | SPA 切换会话（URL `/c/<id>` 改变但网页未刷新）时，旧 `state.bPlan` 未绑定 `conversationId`，且自动循环未检测会话切换，存在跨会话串写风险 |
| **V-02** | 代码 | **Medium** | `src/content.js:119-131` | **已修复** | `findAnswer` 原先对整条消息全文匹配 `marker`；模式 C 的提示词内附带历史原文，若历史原文含同名标记会导致回复匹配错位 |
| **D-01** | 代码 / 隐私 | **Medium** | `src/content.js:256-267, 562-580` | **已修复（方案 B）** | A/C 模式阶段性结果明文保存在 `chrome.storage.local`；现已按方案 B 在导出 Markdown 成功后立即自动调用 `clearJob` 清空本地缓存 |
| **D-02** | 代码 / 注入 | **Medium** | `src/core.js:24-30` | **已修复** | 模式 C 将历史对话包裹在 `【原始数据开始】...【原始数据结束】` 中交由 AI 分析；若历史文本含伪造的结束标记或 `[SECTION:1..6]`，可能逃逸数据块并污染输出结构 |
| **V-03** | 代码 | **Low** | `src/content.js:387-405` | **已修复** | `allowedImageUrl` 原先放行任意源的 `blob:` URL，且 `imageAssets` 在 `fetch` 跟随 30x 重定向后未二次校验最终 `response.url` 是否仍在白名单域名内 |
| **V-04** | 代码 | **Low** | `src/core.js:35-44, 109-138` | **已修复** | `safeUrl` 未编码括号 `()`，`toMarkdown` 未转义链接文本中的 `[]` 且代码块固定使用 3 个反引号，可被构造内容跳出 Markdown 结构 |
| **V-05** | 代码 | **Low** | `src/core.js:387-396` | **已修复** | `archiveHtml` 直接使用 `dataUriByKey[key]`，若 `key` 为 `toString` 等原型属性名会命中 `Object.prototype` |
| **V-06** | 代码 | **Low** | `src/content.js:625-633` | **已修复** | `chrome.runtime.onMessage` 仅校验 `sender.url` 前缀为当前扩展 ID，未精确限制发送方页面路径必须为 `/popup.html` |
| **V-07** | 代码 | **Low** | `src/zip.js:7-12`, `tests/core.test.cjs:64` | **已修复** | `safePath` 未拦截 Windows 盘符/NTFS 备用数据流冒号 `:` 与控制字符；测试文件硬编码 `/tmp` |
| **V-08** | 代码 | **Low** | `manifest.json:15-17` | **已修复** | `manifest.json` 的 `extension_pages` CSP 原为 `"script-src 'self'; object-src 'self'"`，现已收紧为 `default-src 'none'` 与 `object-src 'none'` |

---

## 三、已修复的问题及具体改动

### 1. [V-01 / Medium] SPA 跨会话切换状态隔离
- **位置**：`src/content.js:171-177`、`src/content.js:463-580`
- **原因**：ChatGPT 切换左侧会话不刷新页面，内存中缓存的 `state.bPlan` 以及后台运行中的自动发送循环需绑定当前会话 ID。
- **改动**：
  1. 在 `ensureBPlan` 中记录 `state.bPlan = { conversationId: conversation(), ... }`。
  2. 在 `getState`、`runB`、`processB`、`manualBPrepare` 中校验 `state.bPlan.conversationId !== conversation()`，不一致时立即作废旧缓存。
  3. 在 `runA` 与 `processB` 循环每一步校验 `conversation() !== startConv`，若会话已切换则立即安全中止且不覆盖新会话存储。

### 2. [V-02 / Medium] `findAnswer` 标记匹配范围收紧
- **位置**：`src/content.js:119-131`
- **原因**：防止 `C · 深度分析` 批次提示词中的历史对话原文（位于 `【原始数据开始】` 之后）包含归档标记而触发误匹配。
- **改动**：在 `findAnswer` 中通过 `const head = String(m[i].text||'').split('【原始数据开始】')[0]` 截取纯指令头部后再执行 `head.includes(marker)`。

### 3. [D-01 / Medium] 导出后自动清除 `chrome.storage.local` 敏感缓存（方案 B）
- **位置**：`src/content.js:256-267`（`exportA`）、`src/content.js:562-580`（`exportB`）
- **原因**：避免归档完成并导出文件后，用户的历史对话总结仍长期明文留存在浏览器 `chrome.storage.local` 中。
- **改动**：在 `exportA()` 和 `exportB()` 成功调用 `triggerDownload(...)` 触发本地文件下载后，立即执行 `await clearJob('A')` / `await clearJob('B')`，自动移除 `chrome.storage.local` 中的对应键值并清空内存缓存，同时将状态更新为 `已导出并清除本地缓存`。

### 4. [D-02 / Medium] 批次分析提示词数据块定界符与段落标记防逃逸
- **位置**：`src/core.js:24-30`（`promptB`）
- **原因**：若历史聊天记录中包含恶意构造的 `【原始数据结束】` 或 `[SECTION:1]`，在拼接进 `promptB` 时可能提前闭合数据块或伪造 AI 输出章节。
- **改动**：在 `promptB` 拼接前对 `chunk` 执行边界净化：
  ```js
  const safeChunk = String(chunk ?? '')
    .replace(/【原始数据(?:开始|结束)】/g, '〖原始数据标记已转义〗')
    .replace(/\[SECTION:\s*([1-6])\]/gi, '[DATA_SECTION:$1]');
  ```

### 5. [V-03 / Low] 图片下载 `blob:` 来源校验与重定向目标二次复核
- **位置**：`src/content.js:387-405`
- **原因**：防止非 ChatGPT 域名的 `blob:` URL 或 30x 跨域重定向绕过域名白名单。
- **改动**：限制 `blob:` URL 必须匹配 `/^blob:https:\/\/(?:chatgpt\.com|chat\.openai\.com)\//i`；在 `fetch()` 返回后校验 `if (response.url && !allowedImageUrl(response.url)) throw Error('重定向目标不在允许域名内')`。

### 6. [V-04 / Low] Markdown 导出链接括号、方括号与动态代码围栏防逃逸
- **位置**：`src/core.js:35-44`、`src/core.js:109-138`
- **原因**：防止 URL 中的 `()`、链接文字中的 `[]` 或代码中的三反引号破坏导出的 Markdown 文档结构。
- **改动**：`safeUrl` 将 `(`、`)` 编码为 `%28`、`%29`；`toMarkdown` 转义链接文字中的 `[`、`]`，并根据代码块内最长连续反引号数 `maxTicks` 动态生成 `Math.max(3, maxTicks + 1)` 长度的反引号围栏。

### 7. [V-05 / Low] 离线 HTML 图片键名原型链隔离
- **位置**：`src/core.js:387-396`
- **原因**：防止 `dataUriByKey[key]` 命中 `Object.prototype` 上的属性。
- **改动**：使用 `Object.prototype.hasOwnProperty.call(dataUriByKey, key)` 安全读取。

### 8. [V-06 / Low] 扩展消息通信 `sender.url` 精确路径校验
- **位置**：`src/content.js:625-633`、`tests/content.test.cjs:23-33`
- **原因**：遵循最小权限原则，仅允许扩展弹窗 `/popup.html` 向内容脚本发送控制指令。
- **改动**：将 `sender.url` 校验收紧为 `/^chrome-extension:\/\/<id>\/popup\.html(?:[?#]|$)/`，并在 `tests/content.test.cjs` 中补充了拒绝 `docs/help.html` 的回归测试。

### 9. [V-07 / Low] ZIP 路径校验加固与测试脚本跨平台兼容
- **位置**：`src/zip.js:7-12`、`tests/core.test.cjs:64`
- **原因**：拦截 Windows 盘符/ADS 流冒号 `:` 与控制字符，修复测试脚本在 Windows 下无 `/tmp` 目录的问题。
- **改动**：在 `safePath` 中新增 `p.length > 1024 || p.includes(':') || /[\x00-\x1f\x7f]/.test(p)` 校验；测试临时目录改为 `require('node:os').tmpdir()`。

### 10. [V-08 / Low] `manifest.json` 扩展页面 CSP 策略收紧
- **位置**：`manifest.json:15-17`
- **原因**：禁用 `object-src` 并显式声明 `default-src 'none'`。
- **改动**：更新为 `"default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'; object-src 'none'"`。

---

## 四、密钥与凭据泄露核查

1. **硬编码敏感信息检查**：全量扫描源码、配置、测试、注释、文档与打包产物，**未发现任何硬编码 API Key、Token、密码、私钥、证书、数据库连接串或 Webhook 地址**。
2. **敏感文件与版本控制检查**：项目纯本地运行，无 `.env` 文件；`.gitignore` 已完整配置忽略 `.env`、`.env.*`、`*.pem`、`*.key`、`*.p12`、`*.pfx`、`*.crx`、`*.zip`。

---

## 五、剩余风险与后续建议

1. **真实网页 DOM 演进（建议关注）**：ChatGPT 网页版 DOM 结构若随前端迭代发生变化，选择器可能需要同步更新。当前已内置多级选择器回退并在真实页面验证通过。
2. **AI 总结内容的业务核对（建议关注）**：虽然已对 `promptB` 的数据块边界标记进行了转义防逃逸（D-02），但大语言模型本身仍可能因长上下文产生幻觉或遗漏，建议将 `B · 完整保存` 导出的离线 HTML/MD 原文包作为最终事实依据。
3. **本地 CLI 测试执行说明（待确认）**：因当前 Windows 环境未安装 Node.js 运行时，`npm run check` 命令行执行标注为「**待确认**」；全部代码改动已完成静态语法校验、真实浏览器联调验证及 ZIP 重新打包。
