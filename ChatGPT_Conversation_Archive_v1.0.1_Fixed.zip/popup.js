(() => {
'use strict';
let tabId=null;let activeMode='A';let poll=null;let ready=false;let lastStatus=null;let selectedCatIdx=null;
const $=id=>document.getElementById(id);
function setText(id,text){const el=$(id);if(el)el.textContent=String(text);}
function showError(error){$('error').textContent=String(error||'未知错误');$('error').classList.remove('hidden');}
function clearError(){$('error').textContent='';$('error').classList.add('hidden');}
function humanError(err){return err?.message||String(err||'未知错误');}
function setDisabled(disabled){document.querySelectorAll('button:not(.tab):not(.catBtn)').forEach(b=>{b.disabled=disabled;});}
function showPromptPreview(idx){
  const core=globalThis.ChatArchiveCore;
  if(!core||!Number.isInteger(idx)||idx<0||idx>=6)return '';
  selectedCatIdx=idx;
  const text=core.promptA(idx);
  const box=$('aPromptPreview');
  if(box){box.value=text;box.classList.remove('hidden');}
  document.querySelectorAll('.catBtn').forEach((b,i)=>{b.classList.toggle('activeCat',i===idx);});
  return text;
}
function updateStatus(s){
  if(!s)return;lastStatus=s;
  setText('stage',s.stage||'就绪');setText('progressDetail',s.progress||'');$('dot').style.background=s.busy?'#dca948':'#4a9b87';
  if(s.error)showError(s.error);
  const a=s.aJob||{},b=s.bJob||{};
  const aResults=Array.isArray(a.results)?a.results:[];
  document.querySelectorAll('.catBtn').forEach((btn,i)=>{
    const base=['① 角色设定','② 工作规则','③ 已确定方案','④ 工作进度','⑤ 修改习惯','⑥ 历史图片信息'][i];
    btn.textContent=aResults[i]?`${base} ✓`:base;
    btn.classList.toggle('doneCat',Boolean(aResults[i]));
  });
  setText('aCount',`${a.completed||0} / 6`);setText('aStatus',a.status||'尚未开始');$('aBar').style.width=`${Math.round((a.completed||0)/6*100)}%`;
  if(s.activeTask==='B_ZIP'){
    setText('cZipStatus',s.progress||s.stage||'正在归档…');
    setText('cZipCount',`${s.pct||0}%`);
    if($('cZipBar'))$('cZipBar').style.width=`${s.pct||0}%`;
  }else if(s.stage==='B · 已归档'){
    setText('cZipStatus',s.progress||'归档完成');
    setText('cZipCount','100%');
    if($('cZipBar'))$('cZipBar').style.width='100%';
  }
  if(s.activeTask==='C_SCAN'){
    setText('bStatus',s.progress||s.stage||'正在扫描历史…');
    setText('bCount',`扫描中 ${s.pct||0}%`);
    $('bBar').style.width=`${s.pct||0}%`;
  }else if(s.activeTask==='C_RUN'){
    setText('bStatus',s.progress||s.stage||'正在分析…');
    setText('bCount',`${b.completed||0} / ${b.total||1} (${s.pct||0}%)`);
    $('bBar').style.width=`${s.pct||0}%`;
  }else{
    setText('bCount',`${b.completed||0} / ${b.total||0}`);
    setText('bStatus',b.status||'尚未开始');
    $('bBar').style.width=`${b.total?Math.round((b.completed||0)/b.total*100):0}%`;
  }
  $('pause').disabled=!s.busy;
  const useA=activeMode==='A',useB=activeMode==='B',useC=activeMode==='C';
  const enabled=!s.busy&&ready;
  $('aStart').disabled=!enabled||!useA;
  $('aFill').disabled=!ready||!useA;
  $('aCollect').disabled=!ready||!useA;
  $('aExport').disabled=!enabled||!useA||!(a.completed>0);
  $('aClear').disabled=!enabled||!useA;
  $('cExport').disabled=!enabled||!useB;
  $('bRun').disabled=!enabled||!useC;
  $('bFill').disabled=!enabled||!useC;
  $('bCollect').disabled=!enabled||!useC;
  $('bExport').disabled=!enabled||!useC||!(b.completed>0);
  $('bClear').disabled=!enabled||!useC;
}
async function rpc(type,extra={}){
  if(!ready||tabId===null)throw Error('未连接到 ChatGPT 对话');
  try{
    const response=await chrome.tabs.sendMessage(tabId,{type:`V6_${type}`,...extra});
    if(!response?.ok)throw Error(response?.error||'插件没有收到有效结果');
    return response.data;
  }catch(err){throw Error(humanError(err));}
}
async function refresh(){if(!ready)return;try{const s=await rpc('GET_STATUS');updateStatus(s);}catch(err){setText('stage','页面连接已中断');showError(err.message);}}
async function act(type,extra={}){clearError();try{const result=await rpc(type,extra);await refresh();return result;}catch(err){showError(humanError(err));await refresh();return null;}}
function switchPanel(mode){activeMode=mode;for(const m of ['A','B','C']){$('tab'+m).classList.toggle('active',m===mode);$('tab'+m).setAttribute('aria-selected',String(m===mode));$('panel'+m).classList.toggle('hidden',m!==mode);}updateStatus(lastStatus||{});}
async function initial(){
  try{
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab?.id||!/^https:\/\/(?:chatgpt\.com|chat\.openai\.com)\/(?:[^?#]*\/)?c\/[a-zA-Z0-9-]{6,}/.test(tab.url||''))throw Error('请先切换到已有的 ChatGPT 对话页面（chatgpt.com/c/...）。');
    tabId=tab.id;
    setText('target',`当前对话 · ${new URL(tab.url).pathname.slice(0,55)}`);
    let v6Active=false;
    try{const ping=await chrome.tabs.sendMessage(tabId,{type:'V6_PING'});v6Active=Boolean(ping?.ok);}catch{}
    if(!v6Active){
      try{await chrome.tabs.sendMessage(tabId,{type:'PAUSE'});}catch{}
      await chrome.scripting.executeScript({target:{tabId},files:['src/core.js','src/zip.js','src/content.js']});
    }
    ready=true;clearError();await refresh();
    poll=setInterval(()=>{refresh().catch(()=>{});},800);
  }catch(err){$('target').classList.add('invalid');setText('target','未连接到有效的 ChatGPT 对话');showError(humanError(err));setText('stage','不可用');setDisabled(true);}
}
for(const m of ['A','B','C'])$('tab'+m).addEventListener('click',()=>switchPanel(m));
document.querySelectorAll('.catBtn').forEach(btn=>{
  btn.addEventListener('click',async()=>{
    const idx=Number(btn.getAttribute('data-idx'));
    const text=showPromptPreview(idx);
    try{await navigator.clipboard.writeText(text);}catch{}
    if(ready){
      const r=await act('MANUAL_A_PREPARE',{index:idx});
      if(r)setText('progressDetail',`已填入聊天框并复制第 ${r.step}/6 项（${r.category}）指令`);
      else setText('progressDetail',`已显示并复制第 ${idx+1}/6 项指令，可直接粘贴到聊天框`);
    }else{
      setText('progressDetail',`已显示并复制第 ${idx+1}/6 项指令，可直接粘贴到聊天框`);
    }
  });
});
$('aStart').addEventListener('click',async()=>{
  const operation=document.querySelector('[name="operationA"]:checked').value;
  if(lastStatus?.aJob?.status==='complete'&&!confirm('A 的六项结果已完成。重新开始会覆盖本对话的这份总结记录，确定继续吗？'))return;
  if(operation==='manual'){
    const r=await act('MANUAL_A_PREPARE');
    if(r){showPromptPreview(r.step-1);try{await navigator.clipboard.writeText(r.prompt);}catch{};setText('progressDetail',`已填入并复制第 ${r.step}/6 项（${r.category}）指令`);}
    return;
  }
  await act('START_A',{operation});
});
$('aFill').addEventListener('click',async()=>{
  const r=await act('MANUAL_A_PREPARE');
  if(r){
    showPromptPreview(r.step-1);
    try{await navigator.clipboard.writeText(r.prompt);}catch{}
    setText('progressDetail',`已填入聊天框并复制第 ${r.step}/6 项（${r.category}）指令`);
  }
});
$('aCollect').addEventListener('click',async()=>{
  const r=await act('COLLECT_A');
  if(r)setText('progressDetail',`已收集 ${r.completed}/6 项（最新：${r.category}）`);
});
$('aExport').addEventListener('click',async()=>{const r=await act('EXPORT_A');if(r)setText('progressDetail',`已触发下载：${r.filename}`);});
$('aClear').addEventListener('click',async()=>{if(confirm('删除本对话已保存的六类总结临时结果？此操作不可撤销。')){$('aPromptPreview')?.classList.add('hidden');await act('CLEAR_A');}});
$('cExport').addEventListener('click',async()=>{
  const options={includeBranches:$('cBranches').checked,includeImages:$('cImages').checked};
  const r=await act('EXPORT_C',{options});if(r)setText('progressDetail',`已触发归档下载：${r.filename}`);
});
$('bRun').addEventListener('click',async()=>{
  const operation=document.querySelector('[name="operationB"]:checked').value;
  if(operation==='manual'){
    const r=await act('MANUAL_B_PREPARE');
    if(r)setText('progressDetail',`已填入第 ${r.step}/${r.total} 批指令，发送并等 AI 回复后点击“收集本批回答”`);
    return;
  }
  await act('RUN_B',{operation});
});
$('bFill').addEventListener('click',async()=>{
  const r=await act('MANUAL_B_PREPARE');
  if(r)setText('progressDetail',`已填入第 ${r.step}/${r.total} 批指令`);
});
$('bCollect').addEventListener('click',async()=>{
  const r=await act('COLLECT_B');
  if(r)setText('progressDetail',`已收集第 ${r.step}/${r.total} 批回答`);
});
$('bExport').addEventListener('click',async()=>{const r=await act('EXPORT_B');if(r)setText('progressDetail',`已触发下载：${r.filename}`);});
$('bClear').addEventListener('click',async()=>{if(confirm('删除本对话 C 的暂存结果？'))await act('CLEAR_B');});
$('pause').addEventListener('click',()=>act('PAUSE'));
initial();
})();