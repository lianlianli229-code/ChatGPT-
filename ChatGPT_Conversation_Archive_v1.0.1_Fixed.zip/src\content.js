/* Operates only in the user-authorized ChatGPT tab. No APIs/cookies/token access.
 * The page cannot invoke this listener through DOM postMessage.
 */
(() => {
  'use strict';
  const HOSTS = new Set(['chatgpt.com','chat.openai.com']);
  if (!HOSTS.has(location.hostname) || location.protocol !== 'https:') return;
  const CURRENT_VERSION = 6;
  if (globalThis.__chatArchiveVersion === CURRENT_VERSION) return;
  if (globalThis.__chatArchiveState) {
    globalThis.__chatArchiveState.abort = true;
    globalThis.__chatArchiveState.busy = false;
  }
  globalThis.__chatArchiveVersion = CURRENT_VERSION;
  globalThis.__chatArchiveExtensionReady = true;
  const core = globalThis.ChatArchiveCore;
  const zip = globalThis.ChatArchiveZip;
  if (!core || !zip) return;
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  const SIZE_CAP = 30 * 1024 * 1024;
  const IMAGE_CAP = 5 * 1024 * 1024;
  const MAX_HISTORY_STEPS = 300;
  const MAX_B_BATCHES = 250; // hard cap to prevent runaway automation and cost.
  const state = {busy:false, abort:false, job:null, bPlan:null, archive:null, stage:'未开始', error:'', progress:'', pct:0, activeTask:''};
  globalThis.__chatArchiveState = state;
  const conversation = () => location.pathname.match(/(?:^|\/)c\/([a-zA-Z0-9-]{6,100})(?:\/|$)/)?.[1] || null;
  const jobKey = mode => `archive_v1_${mode}_${conversation() || 'unknown'}`;
  const title = () => document.title.replace(/\s*[-–|]\s*ChatGPT.*$/,'').trim().slice(0,120) || 'ChatGPT 对话';
  function requireConversation() { if (!conversation()) throw Error('请先打开具体的 ChatGPT 对话页面（/c/…），不要在主页或临时聊天中操作。'); }
  function requireIdle() {if (state.busy) throw Error('另一项任务仍在执行，请先暂停或等待完成。');}
  function checkStop(){if(state.abort)throw Error('已暂停：任务已保存当前进度。');}
  const getSaved = async mode => (await chrome.storage.local.get(jobKey(mode)))[jobKey(mode)] || null;
  async function saveJob(mode, data) {
    const updated = {...data, updatedAt:new Date().toISOString()};
    await chrome.storage.local.set({[jobKey(mode)]:updated});
    state.job = updated;
    return updated;
  }
  const status = () => ({busy:state.busy,stage:state.stage,error:state.error,progress:state.progress,pct:state.pct||0,activeTask:state.activeTask||'',conversation:conversation(),bReady:!!state.bPlan,bBatches:state.bPlan?.chunks.length||0,bMessages:state.bPlan?.messages.length||0,bCharacters:state.bPlan?.chunks.reduce((n,c)=>n+c.text.length,0)||0, job:state.job ? {mode:state.job.mode,status:state.job.status,step:state.job.step,results:(state.job.results||[]).map(x=>Boolean(x)),operation:state.job.operation,total:state.job.total||6,updatedAt:state.job.updatedAt} : null});
  function safeFilename(type, ext) {return `ChatGPT_${type}_${new Date().toISOString().slice(0,10)}.${ext}`;}
  function triggerDownload(blob,name) {
    // Content-script anchor download requires no cloud server or downloads permission.
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download=name;a.style.display='none';
    (document.body||document.documentElement).appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url), 60000);
    return name;
  }
  function asBlob(content,type='text/markdown;charset=utf-8'){return new Blob([content],{type});}
  function currentMessages(){return (globalThis.ChatArchiveCore || core).extractMessages(document);}
  function findEditor() {
    const selectors = ['#prompt-textarea[contenteditable="true"]','[data-testid="composer-input"][contenteditable="true"]','[contenteditable="true"][role="textbox"]','textarea#prompt-textarea','textarea[placeholder]'];
    for(const selector of selectors){const nodes=Array.from(document.querySelectorAll(selector));const found=nodes.find(n=>n.getClientRects().length>0 && !n.closest('[aria-hidden="true"]'));if(found)return found;}
    return null;
  }
  function isDraftEmpty(editor) {
    const raw = editor instanceof HTMLTextAreaElement ? editor.value : (editor.innerText || editor.textContent || '');
    const cleaned = raw.replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
    if (!cleaned && !editor.querySelector?.('img,figure,[data-testid*="attachment"]')) return true;
    if (raw.includes('【对话归档任务 A') || raw.includes('【独立历史档案分批分析 B：') || raw.includes('仅依据你在当前会话中实际可访问的历史消息回答')) return true;
    return false;
  }
  function fillPrompt(text) {
    const editor=findEditor();if(!editor)throw Error('找不到 ChatGPT 输入框。网页结构可能已改变，请切换手动模式。');
    if(!isDraftEmpty(editor))throw Error('输入框中已有未发送内容。为了防止覆盖你的草稿，已停止操作。');
    editor.focus();
    if(typeof HTMLTextAreaElement!=='undefined' && editor instanceof HTMLTextAreaElement){
      const setter=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value')?.set;
      if(setter)setter.call(editor,text);else editor.value=text;
      editor.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));
    }else{
      try {
        const selection=window.getSelection?.();
        const range=document.createRange?.();
        if(selection && range){
          range.selectNodeContents(editor);range.collapse(false);selection.removeAllRanges();selection.addRange(range);
        }
      } catch(_e){}
      let success=false;
      try {success=document.execCommand('insertText',false,text);} catch(_error){}
      if(!success || !(editor.textContent || '').includes(text.slice(0,40))){
        if(typeof document.createElement==='function' && editor.tagName?.toLowerCase()!=='textarea'){
          const p=document.createElement('p');
          p.textContent=text;
          editor.replaceChildren(p);
        }else{
          editor.replaceChildren(document.createTextNode(text));
        }
        try{editor.dispatchEvent(new InputEvent('beforeinput',{bubbles:true,cancelable:true,inputType:'insertText',data:text}));}catch(_e){}
        editor.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));
      }
    }
    const actual=(typeof HTMLTextAreaElement!=='undefined' && editor instanceof HTMLTextAreaElement)?editor.value:editor.textContent;
    if(!actual?.includes(text.slice(0,50)))throw Error('无法确认指令已经填入输入框，已停止。');
    return editor;
  }
  function sendButton(editor) {
    const form=editor.closest?.('form');
    const selectors=['button[data-testid="send-button"]','button[data-testid="composer-send-button"]','button.composer-submit-btn','button[aria-label="Send prompt"]','button[aria-label="Send message"]','button[aria-label="发送消息"]','button[aria-label="发送提示词"]','button[type="submit"]'];
    for(const selector of selectors){const found=selector==='button[type="submit"]' ? form?.querySelector(selector) : (form?.querySelector(selector) || document.querySelector(selector));if(found && !found.disabled && found.getClientRects().length>0)return found;}
    return null;
  }
  async function sendPrompt(prompt) {
    checkStop(); if(generationRunning())throw Error('页面仍在生成回答，请等待结束后再开始下一项。'); const editor=fillPrompt(prompt);
    await wait(300);checkStop();
    let send=sendButton(editor);
    for(let tries=0;tries<8&&!send;tries++){await wait(250);send=sendButton(editor);checkStop();}
    if(!send)throw Error('找不到可用的发送按钮，已保留待发送指令，请手动发送后使用“收集当前回答”。');
    send.click();
    await wait(450);
    const remaining=(typeof HTMLTextAreaElement!=='undefined' && editor instanceof HTMLTextAreaElement)?editor.value:(editor.textContent||'');
    if(remaining.includes(prompt.slice(0,40))){
      try{send.closest?.('form')?.requestSubmit?.();}catch(_e){}
      try{editor.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true}));}catch(_e){}
      await wait(350);
    }
  }
  function findAnswer(marker, latestOnly=false){
    const m=currentMessages();
    let unanswered=null;
    for(let i=m.length-1;i>=0;i--){
      const head=String(m[i].text||'').split('【原始数据开始】')[0];
      if(m[i].role==='user'&&head.includes(marker)){
        const nextUser=m.findIndex((x,idx)=>idx>i&&x.role==='user');
        const slice=nextUser===-1?m.slice(i+1):m.slice(i+1,nextUser);
        const next=slice.find(x=>x.role==='assistant'&&(x.text||'').trim().length>0);
        if(next)return {question:m[i],answer:next};
        if(latestOnly)return {question:m[i],answer:null};
        if(!unanswered)unanswered={question:m[i],answer:null};
      }
    }
    return unanswered;
  }
  function generationRunning(){
    const selectors=['button[data-testid="stop-button"]','button[aria-label="Stop generating"]','button[aria-label="Stop streaming"]','button[aria-label="停止生成"]','button[aria-label="停止回答"]'];
    return selectors.some(sel=>Array.from(document.querySelectorAll(sel)).some(n=>{
      if(n.disabled||n.getAttribute?.('aria-disabled')==='true'||n.closest?.('[aria-hidden="true"]'))return false;
      const rects=n.getClientRects?.();
      return rects && rects.length>0 && (typeof n.getBoundingClientRect!=='function' || n.getBoundingClientRect().width>0);
    }));
  }
  async function awaitAnswer(marker,timeoutMs=300000,latestOnly=false,stepLabel='',onTextProgress=null){
    const started=Date.now();let previous='',stableSince=Date.now();
    while(Date.now()-started<timeoutMs){
      checkStop();const match=findAnswer(marker,latestOnly);
      if(match?.answer){
        const text=match.answer.text.trim();
        if(text!==previous){previous=text;stableSince=Date.now();}
        if(stepLabel)state.progress=`${stepLabel}（正在接收 AI 回复：${text.length} 字…）`;
        if(typeof onTextProgress==='function')try{onTextProgress(text.length);}catch{}
        if(text.length>10&&!generationRunning()&&Date.now()-stableSince>=2200)return text;
      }else if(stepLabel){
        state.progress=`${stepLabel}（已发送，等待 AI 回复…）`;
      }
      await wait(800);
    }
    throw Error('未能可靠确认 AI 回答已完成，任务暂停。请在页面确认后点击“收集当前回答”，避免重复发送。');
  }
  function aMarker(i){return `【对话归档任务 A${i+1}/6：`;}
  async function startA(operation){
    requireConversation();requireIdle();
    if(!['auto','manual'].includes(operation))throw Error('不支持的执行方式');
    const saved=await getSaved('A');
    const fresh= saved && saved.status!=='complete' ? saved : {mode:'A',status:'ready',operation,step:0,results:Array(6).fill(null),createdAt:new Date().toISOString()};
    fresh.operation=operation;
    await saveJob('A',fresh);
    state.error='';
    if(operation==='auto') runA().catch(err=>{state.error=err.message;});
    return status();
  }
  async function runA(){
    requireIdle();state.busy=true;state.abort=false;state.stage='A · 逐项自动总结';
    const startConv=conversation();
    let job=(await getSaved('A'))||{mode:'A',results:Array(6).fill(null),step:0};
    try{
      for(let i=0;i<6;i++){
        if(job.results[i])continue;
        if(conversation()!==startConv)throw Error('检测到对话已切换，为防止跨会话写入已自动暂停。');
        const label=`${i+1}/6 · ${core.CATEGORIES[i][0]}`;
        checkStop();job.step=i;job.status='running';job.operation='auto';
        state.progress=label;
        await saveJob('A',job);
        const existing=findAnswer(aMarker(i));
        if(existing?.answer){
          // A previous send may have succeeded before browser/popup interrupted.
          if(generationRunning()){
            const value=await awaitAnswer(aMarker(i),300000,false,label);job.results[i]=value;
          }else{
            job.results[i]=existing.answer.text;
            job.step=i+1;await saveJob('A',job);
            await wait(250);
            continue;
          }
        }else if(existing && generationRunning()){
          job.results[i]=await awaitAnswer(aMarker(i),300000,false,label);
        }else{
          state.progress=`${label}（正在填入并发送…）`;
          await sendPrompt(core.promptA(i));
          job.results[i]=await awaitAnswer(aMarker(i),300000,true,label);
        }
        job.step=i+1;await saveJob('A',job);
        await wait(1000); // pace messages, never rapid-fire.
      }
      job.status='complete';state.stage='A · 已完成';state.progress='六项结果已全部收集完成';await saveJob('A',job);
    }catch(err){
      job.status='paused';job.lastError=err.message;await saveJob('A',job);state.error=err.message;state.stage='A · 已暂停';
    }finally{state.busy=false;state.abort=false;}
  }
  async function prepareManualA(requestedIndex){
    if(state.busy){state.abort=true;await wait(400);}
    requireConversation();
    let job=await getSaved('A');
    if(!job)job={mode:'A',status:'ready',operation:'manual',step:0,results:Array(6).fill(null),createdAt:new Date().toISOString()};
    for(let k=0;k<6;k++){
      if(!job.results[k]){
        const prevMatch=findAnswer(aMarker(k));
        if(prevMatch?.answer && !generationRunning())job.results[k]=prevMatch.answer.text;
      }
    }
    const i=Number.isInteger(requestedIndex)&&requestedIndex>=0&&requestedIndex<6 ? requestedIndex : job.results.findIndex(x=>!x);
    if(i===-1){job.status='complete';await saveJob('A',job);throw Error('六项结果已全部收集，可直接点击导出！');}
    const promptText=core.promptA(i);
    try{fillPrompt(promptText);}catch(_e){}
    job.step=i;job.status='manual-waiting';job.operation='manual';await saveJob('A',job);
    state.stage=`A · 已准备第 ${i+1}/6 项（${core.CATEGORIES[i][0]}）`;
    state.progress=`${i+1}/6 · ${core.CATEGORIES[i][0]}`;
    return {step:i+1,category:core.CATEGORIES[i][0],prompt:promptText};
  }
  async function collectA(){
    if(state.busy){state.abort=true;await wait(400);}
    requireConversation();
    let job=await getSaved('A');
    if(!job)job={mode:'A',status:'ready',operation:'manual',step:0,results:Array(6).fill(null),createdAt:new Date().toISOString()};
    let collectedCount=0;let lastStep=0;let lastCat='';
    for(let k=0;k<6;k++){
      if(job.results[k])continue;
      const matched=findAnswer(aMarker(k));
      if(matched?.answer && !generationRunning()){
        job.results[k]=matched.answer.text;
        collectedCount++;lastStep=k+1;lastCat=core.CATEGORIES[k][0];
      }
    }
    if(!collectedCount){
      const nextIdx=job.results.findIndex(x=>!x);
      if(nextIdx===-1)throw Error('六项已完成，可直接点击导出！');
      throw Error(`尚未识别到“${core.CATEGORIES[nextIdx][0]}”的完整回答，请确认已发送该指令且页面已生成完毕。`);
    }
    const nextUnfinished=job.results.findIndex(x=>!x);
    job.step=nextUnfinished===-1?6:nextUnfinished;
    job.status=nextUnfinished===-1?'complete':'ready';
    await saveJob('A',job);
    state.stage=job.status==='complete'?'A · 已完成':'A · 已收集，可填入下一条';
    state.progress=job.status==='complete'?'6/6 全部完成':`已收集 ${job.results.filter(Boolean).length}/6 · 下一项：${core.CATEGORIES[job.step][0]}`;
    return {step:lastStep,category:lastCat,completed:job.results.filter(Boolean).length};
  }
  async function exportA(){
    requireIdle();let job=await getSaved('A');if(!job)throw Error('没有 A 总结结果');
    const completed=job.results.filter(Boolean).length;
    if(!completed)throw Error('还没有已完成的总结');
    const notes=[`已完成：${completed}/6 项。`,`导出时间：${new Date().toISOString()}。`,'无法保证 ChatGPT 当前上下文覆盖所有历史，内容需要用户核对。'];
    if(job.results.some(x=>!x))notes.push('此文件含未完成分类，不应作为完整继承档案。');
    const md=core.combinedMarkdown(job.results,'A','ChatGPT 旧窗口继承档案',notes);
    const filename=triggerDownload(asBlob(md),safeFilename('A_六类继承档案','md'));
    await clearJob('A');
    state.stage='A · 已导出并清除本地缓存';
    return {filename,completed};
  }
  async function clearJob(mode){
    requireIdle();if(!['A','B'].includes(mode))throw Error('不支持的任务');
    await chrome.storage.local.remove(jobKey(mode));
    if(state.job?.mode===mode)state.job=null;
    if(mode==='B')state.bPlan=null;
    return status();
  }
  function scrollContainer(){
    const any=document.querySelector('[data-message-author-role], [data-testid^="conversation-turn-"], [data-turn], [data-message-id], main article, main .markdown');
    let cur=any?.parentElement;let fallback=null;
    while(cur&&cur!==document.body){
      const style=getComputedStyle(cur);
      if(/auto|scroll/.test(style.overflowY) && cur.scrollHeight>cur.clientHeight+100){fallback=cur;break;}
      cur=cur.parentElement;
    }
    return fallback||document.scrollingElement||document.documentElement;
  }
  async function extractHistory(pctMin=5,pctMax=90){
    requireConversation();state.stage='正在读取可访问的历史消息';state.progress='准备扫描';state.pct=pctMin;
    const scroller=scrollContainer();
    const topWas=scroller.scrollTop;
    const initTop=Math.max(1,topWas);
    const bottomDistance=scroller.scrollHeight-scroller.clientHeight-scroller.scrollTop;
    let merged=[];let orderUnverified=false;let scans=0;let atTop=0;let reachedTop=false;
    for(let i=0;i<MAX_HISTORY_STEPS;i++){
      checkStop();
      const snap=currentMessages();const result=core.mergeMessages(merged,snap);
      merged=result.messages;orderUnverified ||=result.orderUnverified;
      scans=i+1;
      const ratio=topWas>2?Math.min(0.85,Math.max(0,1-(scroller.scrollTop/initTop))*0.85):Math.min(0.85,scans*0.18);
      const topBonus=atTop*0.03;
      state.pct=Math.min(pctMax,Math.round(pctMin+(pctMax-pctMin)*Math.min(1,ratio+topBonus)));
      state.progress=`读取第 ${scans} 次页面 · 已发现 ${merged.length} 条消息`;
      if(scroller.scrollTop<=2)atTop++;else atTop=0;
      if(atTop>=5){reachedTop=true;break;}
      const before=scroller.scrollTop;
      scroller.scrollTop=Math.max(0,before-Math.max(320,scroller.clientHeight*0.72));
      if(scroller===document.scrollingElement)window.scrollTo(0,scroller.scrollTop);
      await wait(before<=2?600:260);
    }
    // One final snapshot after lazy-loaded content settles.
    await wait(500);const last=core.mergeMessages(merged,currentMessages());merged=last.messages;orderUnverified||=last.orderUnverified;
    state.pct=pctMax;
    scroller.scrollTop=Math.max(0,scroller.scrollHeight-scroller.clientHeight-bottomDistance);
    if(scroller===document.scrollingElement)window.scrollTo(0,scroller.scrollTop);
    return {messages:merged,report:{scanSteps:scans,reachedTop,orderUnverified,messageCount:merged.length,coverage:'仅已加载/可访问网页，无法证明服务端历史完整',maxStepsReached:scans>=MAX_HISTORY_STEPS,initialScrollTop:topWas}};
  }
  function variantButtons(){
    // Strict allow-list only: never trigger regenerate/edit/send controls.
    const labels={prev:/^(previous (response|version|answer)|上一(个)?(回答|版本)|前一个(回答|版本))$/i,next:/^(next (response|version|answer)|下一(个)?(回答|版本)|后一个(回答|版本))$/i};
    return Array.from(document.querySelectorAll('button[aria-label]'))
      .filter(b=>b.getClientRects().length>0)
      .filter(b=>Object.values(labels).some(r=>r.test((b.getAttribute('aria-label')||'').trim())))
      .map(b=>({el:b,dir:labels.prev.test(b.getAttribute('aria-label').trim())?'prev':'next',
        turnId:b.closest('[data-testid^="conversation-turn-"]')?.getAttribute('data-testid')||null}));
  }
  async function scanAccessibleVariants(base){
    const snapshots=[];const visited=new Set();let merged=base.slice();let clicks=0,stalled=false,restored=true;
    const initialControls=variantButtons();
    const turnIds=[...new Set(initialControls.map(c=>c.turnId).filter(Boolean))].slice(0,12);
    if(!turnIds.length && initialControls.length)turnIds.push('__unscoped__');
    const signature=()=>core.hash(currentMessages().map(m=>m.id).join('|'));
    function remember(name){
      const snapshot=currentMessages(),sig=signature();
      if(!visited.has(sig)){
        visited.add(sig);snapshots.push({name,signature:sig,messageIds:snapshot.map(m=>m.id)});
        merged=core.mergeMessages(merged,snapshot).messages;
      }
    }
    remember('当前选中分支');
    function control(dir,turnId){
      const buttons=variantButtons().filter(c=>c.dir===dir&&!c.el.disabled);
      if(turnId==='__unscoped__')return buttons[0]?.el||null;
      return buttons.find(c=>c.turnId===turnId)?.el||null;
    }
    async function move(dir,turnId,label){
      if(clicks>=80)return false;
      const b=control(dir,turnId);if(!b)return false;
      const before=signature();b.click();clicks++;await wait(850);remember(label);
      if(signature()===before){stalled=true;return false;}
      return true;
    }
    // Each version selector is inspected independently; always attempt to restore its initial position.
    for(const turnId of turnIds){
      checkStop();const beginning=signature();
      let localRestored=true;let phase='start';
      try{
        for(let i=0;i<12;i++){
          checkStop();if(clicks>=56)break;
          if(!await move('prev',turnId,`${turnId} · 较早版本 ${i+1}`))break;
          phase='older';
        }
        // Return to the starting version before exploring newer versions.
        for(let i=0;i<16 && signature()!==beginning;i++){
          if(!await move('next',turnId,`${turnId} · 返回原始版本 ${i+1}`))break;
        }
        if(signature()!==beginning){localRestored=false;break;}
        phase='start';
        for(let i=0;i<12;i++){
          checkStop();if(clicks>=56)break;
          if(!await move('next',turnId,`${turnId} · 较新版本 ${i+1}`))break;
          phase='newer';
        }
      }finally{
        // Do not skip restoration when the user pauses or an exception occurs.
        const back=phase==='older'?'next':'prev';
        for(let i=0;i<18 && signature()!==beginning;i++){
          if(!await move(back,turnId,`${turnId} · 恢复页面 ${i+1}`))break;
        }
        // Best effort if page changed while moving through version controls.
        const opposite=back==='prev'?'next':'prev';
        for(let i=0;i<8 && signature()!==beginning;i++){
          if(!await move(opposite,turnId,`${turnId} · 再次尝试恢复 ${i+1}`))break;
        }
        if(signature()!==beginning)localRestored=false;
        restored &&= localRestored;
      }
      if(!localRestored || clicks>=80)break;
    }
    return {messages:merged,snapshots,report:{controlsDetected:initialControls.length>0,
      controlsByTurn:turnIds.length,clicks,restored,stalled,allBranchesVerified:false,
      limitations:'仅扫描可见且有明确无歧义标签的版本切换控件，最多检查12处控件与80次切换；分支树关系和隐藏版本无法完全验证。'}};
  }
  function allowedImageUrl(src){
    if(typeof src!=='string'||!src)return false;
    if(/^data:image\/(?:png|jpeg|webp|gif);base64,/i.test(src))return true;
    if(src.startsWith('blob:'))return /^blob:https:\/\/(?:chatgpt\.com|chat\.openai\.com)\//i.test(src);
    try{const u=new URL(src,location.href);return u.protocol==='https:'&&['openai.com','chatgpt.com','oaistatic.com','oaiusercontent.com'].some(d=>u.hostname===d||u.hostname.endsWith('.'+d));}catch{return false;}
  }
  async function imageAssets(messages){
    const files=[],dataUri={},failures=[];let total=0;const found=new Set();
    const images=messages.flatMap(m=>m.images||[]);
    for(let i=0;i<images.length;i++){
      checkStop();const img=images[i];if(found.has(img.key))continue;found.add(img.key);
      if(!img.sourceUrl||!allowedImageUrl(img.sourceUrl)){img.status='无法安全获取/不允许来源';failures.push(img.key);continue;}
      if(total>=SIZE_CAP){img.status='总资源大小达到安全上限';failures.push(img.key);continue;}
      try{
        const response=await fetch(img.sourceUrl,{method:'GET',credentials:'omit',referrerPolicy:'no-referrer',mode:'cors',signal:AbortSignal.timeout(12000)});
        if(!response.ok)throw Error('资源请求失败');
        if(response.url && !allowedImageUrl(response.url))throw Error('重定向目标不在允许域名内');
        const mime=(response.headers.get('content-type')||'').split(';')[0].toLowerCase();
        if(!['image/png','image/jpeg','image/webp','image/gif'].includes(mime))throw Error('图片格式不支持');
        const declared=Number(response.headers.get('content-length')||'0');
        if(declared>IMAGE_CAP||declared+total>SIZE_CAP)throw Error('图片超过大小上限');
        const blob=await response.blob();if(blob.size>IMAGE_CAP||blob.size+total>SIZE_CAP)throw Error('图片超过大小上限');
        const raw=new Uint8Array(await blob.arrayBuffer());total+=raw.length;
        const extension={'image/png':'png','image/jpeg':'jpg','image/webp':'webp','image/gif':'gif'}[mime];
        const filename=`assets/${img.key.replace(/[^a-zA-Z0-9_-]/g,'_')}.${extension}`;
        files.push({name:filename,data:raw});img.status='已保存';img.assetPath=filename;
        // Inline image for offline HTML (safe MIME, never SVG or remote references).
        const base64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(Error('读取失败'));reader.onload=()=>resolve(reader.result);reader.readAsDataURL(blob);});
        if(/^data:image\/(?:png|jpeg|webp|gif);base64,/.test(base64))dataUri[img.key]=base64;
      }catch(e){img.status='未保存：'+String(e.message).slice(0,90);failures.push(img.key);}
      state.pct=65+Math.round(((i+1)/Math.max(1,images.length))*27);
      state.progress=`图片处理 ${i+1}/${images.length} · 成功 ${files.length}`;
    }
    return {files,dataUri,failures,attempted:images.length,success:files.length,totalBytes:total};
  }
  async function exportC(options){
    requireIdle();state.busy=true;state.abort=false;state.activeTask='B_ZIP';state.pct=5;state.stage='B · 正在提取和归档';state.error='';
    try{
      const base=await extractHistory(5,45);let messages=base.messages;let branches={snapshots:[],report:{controlsDetected:false,allBranchesVerified:false}};
      if(options?.includeBranches!==false){state.stage='B · 正在尝试读取历史分支';state.pct=55;branches=await scanAccessibleVariants(messages);messages=branches.messages;}
      if(!messages.length)throw Error('未识别到聊天消息，网页结构可能改变。');
      state.stage='B · 正在保存可访问图片';state.pct=65;
      const assets=options?.includeImages===false?{files:[],dataUri:{},failures:[],attempted:0,success:0,totalBytes:0}:await imageAssets(messages);
      const imageCount=messages.reduce((s,m)=>s+(m.images?.length||0),0);
      const attachmentCount=messages.reduce((s,m)=>s+(m.attachments?.length||0),0);
      const report={mode:'B',date:new Date().toISOString(),conversationId:conversation(),messageCount:messages.length,imagesDiscovered:imageCount,imagesSaved:assets.success,missingAssets:imageCount-assets.success,attachmentsDiscovered:attachmentCount,attachmentsSaved:0,scan:base.report,branches:branches.report,branchSnapshots:branches.snapshots.length,privacy:'无 API/Token/Cookie 读取；无外部上传；图片仅尝试从受限可信来源下载（credentials:omit）',completeness:'未验证完整性；无法保证全部历史分支、隐藏历史及原始图片可获取'};
      const md=core.archiveMarkdown(messages,title());
      const html=core.archiveHtml(messages,title(),assets.dataUri,report);
      const serial=messages.map(core.stripPrivateImage);
      const json=JSON.stringify({version:1,title:title(),report,messages:serial,branchSnapshots:branches.snapshots},null,2);
      state.stage='B · 正在打包';state.pct=95;
      const entries=[{name:'conversation.html',data:html},{name:'conversation.md',data:md},{name:'conversation.json',data:json},{name:'report.json',data:JSON.stringify(report,null,2)},...assets.files];
      const blob=zip.build(entries);
      const file=triggerDownload(blob,safeFilename('B_完整对话','zip'));
      state.pct=100;state.stage='B · 已归档';state.progress=`${messages.length} 条消息，${assets.success}/${imageCount} 张图片已保存`;
      return {filename:file,report};
    }catch(error){state.error=error.message;state.stage='B · 失败';throw error;}
    finally{state.busy=false;state.abort=false;state.activeTask='';}
  }
  function filterBusinessMessages(messages){
    const filtered=[];
    for(let i=0;i<messages.length;i++){
      const m=messages[i];
      const txt=(m.text||'').trim();
      const isArchivePrompt=m.role==='user' && (txt.includes('【对话归档任务 A') || txt.includes('【独立历史档案分批分析 B：') || txt.startsWith('仅依据你在当前会话中实际可访问的历史消息回答'));
      if(isArchivePrompt){
        if(i+1<messages.length && messages[i+1].role==='assistant')i++;
        continue;
      }
      filtered.push(m);
    }
    return filtered.length?filtered:messages;
  }
  async function ensureBPlan(pctMax=25){
    const scan=await extractHistory(5,pctMax);
    const clean=filterBusinessMessages(scan.messages);
    if(!clean.length)throw Error('未找到可访问的对话消息');
    const chunks=core.splitIntoChunks(clean,30000);
    if(chunks.length>MAX_B_BATCHES)throw Error(`本次发现 ${chunks.length} 批，超过安全上限 ${MAX_B_BATCHES} 批。`);
    state.bPlan={conversationId:conversation(),messages:clean,chunks,report:scan.report};
    let job=await getSaved('B');
    if(!job||job.status==='complete'||job.total!==chunks.length){
      job={mode:'B',status:'prepared',step:0,total:chunks.length,operation:'auto',results:Array(chunks.length).fill(null),signatures:chunks.map(c=>c.signature),createdAt:new Date().toISOString()};
    }else{
      job.results=job.results.map((result,i)=>job.signatures?.[i]===chunks[i]?.signature?result:null);
      job.signatures=chunks.map(c=>c.signature);job.status='prepared';job.step=job.results.findIndex(x=>!x);if(job.step<0)job.step=chunks.length;
    }
    return await saveJob('B',job);
  }
  async function prepareB(){
    requireIdle();requireConversation();state.busy=true;state.abort=false;state.activeTask='C_SCAN';state.pct=5;state.error='';state.stage='C · 正在扫描历史';
    try{
      const job=await ensureBPlan(95);
      state.pct=100;state.stage='C · 扫描完成';state.progress=`已识别 ${state.bPlan.messages.length} 条有效消息，合并为 ${state.bPlan.chunks.length} 批`;
      return {messages:state.bPlan.messages.length,batches:state.bPlan.chunks.length,charCount:state.bPlan.chunks.reduce((s,c)=>s+c.text.length,0),scan:state.bPlan.report,job};
    }catch(error){state.error=error.message;state.stage='C · 扫描失败';throw error;}
    finally{state.busy=false;state.abort=false;state.activeTask='';}
  }
  const bMarker=i=>`【独立历史档案分批分析 B：${i+1}/`;
  async function runB(operation='auto'){
    requireIdle();requireConversation();
    if(!['auto','manual'].includes(operation))throw Error('请选择自动或手动模式');
    state.error='';
    if(operation==='auto'){
      processB().catch(e=>{state.error=e.message;});
      return status();
    }
    state.busy=true;state.abort=false;state.activeTask='C_SCAN';
    try{
      if(!state.bPlan || state.bPlan.conversationId!==conversation())await ensureBPlan(95);
      let job=await getSaved('B');
      job.operation='manual';job.status='ready';await saveJob('B',job);
      return status();
    }finally{state.busy=false;state.abort=false;state.activeTask='';}
  }
  async function processB(){
    requireIdle();const startConv=requireConversation();state.busy=true;state.abort=false;state.activeTask='C_SCAN';state.pct=5;state.stage='C · 正在扫描并分析历史';
    let job=await getSaved('B');
    try{
      if(!state.bPlan || state.bPlan.conversationId!==startConv || !job || job.total!==state.bPlan.chunks?.length){
        job=await ensureBPlan(22);
      }
      state.activeTask='C_RUN';state.stage='C · 分批分析六类信息';
      const total=state.bPlan.chunks.length;
      for(let i=0;i<total;i++){
        if(job.results[i])continue;
        if(conversation()!==startConv)throw Error('当前会话已切换，自动分析已安全中止');
        const label=`C 第 ${i+1}/${total} 批`;
        const basePct=22+Math.round((i/total)*76);
        const spanPct=Math.round(76/total);
        state.pct=basePct+Math.round(spanPct*0.1);
        checkStop();job.step=i;job.status='running';job.operation='auto';state.progress=`${label}（准备分析 ${state.bPlan.messages.length} 条有效消息…）`;
        await saveJob('B',job);
        const existing=findAnswer(bMarker(i));
        const onProg=len=>{state.pct=Math.min(98,basePct+Math.round(spanPct*Math.min(0.92,0.2+Math.min(len/1200,0.72))));};
        let answer;
        if(existing?.answer)answer=generationRunning()?await awaitAnswer(bMarker(i),300000,false,label,onProg):existing.answer.text;
        else if(existing && generationRunning())answer=await awaitAnswer(bMarker(i),300000,false,label,onProg);
        else{
          state.progress=`${label}（正在填入并发送…）`;
          state.pct=basePct+Math.round(spanPct*0.18);
          await sendPrompt(core.promptB(state.bPlan.chunks[i].text,i+1,total));
          answer=await awaitAnswer(bMarker(i),300000,true,label,onProg);
        }
        job.results[i]=answer;job.step=i+1;state.pct=22+Math.round(((i+1)/total)*76);
        await saveJob('B',job);await wait(900);
      }
      state.pct=100;job.status='complete';await saveJob('B',job);state.stage='C · 已完成';state.progress=`已完成全部 ${total} 批分析，可导出合并档案`;
    }catch(err){if(job){job.status='paused';job.lastError=err.message;if(conversation()===startConv)await saveJob('B',job);}state.error=err.message;state.stage='C · 已暂停';}
    finally{state.busy=false;state.abort=false;state.activeTask='';}
  }
  async function manualBPrepare(){
    if(state.busy){state.abort=true;await wait(400);}
    const curConv=requireConversation();
    if(!state.bPlan || state.bPlan.conversationId!==curConv){
      state.busy=true;state.activeTask='C_SCAN';
      try{await ensureBPlan(95);}finally{state.busy=false;state.activeTask='';}
    }
    let job=await getSaved('B');if(!job)throw Error('找不到 C 任务');
    const i=job.results.findIndex(x=>!x);if(i===-1)throw Error('C 已全部完成，可直接导出');
    fillPrompt(core.promptB(state.bPlan.chunks[i].text,i+1,state.bPlan.chunks.length));
    job.status='manual-waiting';job.step=i;job.operation='manual';await saveJob('B',job);state.stage='C · 等待手动发送';
    return {step:i+1,total:state.bPlan.chunks.length};
  }
  async function collectB(){
    requireIdle();let job=await getSaved('B');if(!job)throw Error('找不到 C 任务');
    const i=job.results.findIndex(x=>!x);if(i===-1)throw Error('C 已完成');
    const match=findAnswer(bMarker(i));if(!match?.answer||generationRunning())throw Error('未找到本批已完成的 AI 回答');
    job.results[i]=match.answer.text;job.step=i+1;job.status=job.step===job.total?'complete':'ready';await saveJob('B',job);
    return {step:i+1,total:job.total};
  }
  async function exportB(){
    requireIdle();let job=await getSaved('B');if(!job||!job.results.some(Boolean))throw Error('没有 C 分析结果');
    const completed=job.results.filter(Boolean).length;
    const total=job.total;
    const sections=Array.from({length:6},()=>[]);let malformed=0;
    job.results.forEach((output,i)=>{
      if(!output)return;
      const result=core.parseBSections(output);
      if(!result.complete)malformed++;
      result.parts.forEach((part,j)=>{if(part.trim())sections[j].push(`### 第 ${i+1} 批\n${part.trim()}`);});
    });
    const merged=sections.map(parts=>parts.join('\n\n')||'未得到可验证的提取结果');
    const notes=[`已分析：${completed}/${total} 批。`,'每批独立同时提取六类；此档案将结果按类别汇集，跨批次冲突和重复仍需用户检查。',`缺少规范分隔标记的批次：${malformed}。`,'来源是当前网页可访问的聊天记录，不能证明覆盖全部服务端历史。'];
    if(job.results.some(x=>!x))notes.push('警告：部分批次尚未完成。');
    const md=core.combinedMarkdown(merged,'C','ChatGPT 深度历史继承档案',notes);
    const filename=triggerDownload(asBlob(md),safeFilename('C_深度分析档案','md'));
    await clearJob('B');
    state.stage='C · 已导出并清除本地缓存';
    return {filename,completed,total,malformed};
  }
  async function getState(){
    if(state.bPlan && state.bPlan.conversationId!==conversation())state.bPlan=null;
    let a=await getSaved('A'),b=await getSaved('B');
    if(!state.busy){
      try {
        const msgs=currentMessages();
        const uCnt=msgs.filter(x=>x.role==='user').length;
        const aCnt=msgs.filter(x=>x.role==='assistant').length;
        if(!state.progress || state.progress.startsWith('当前页已识别')){
          state.progress=`当前页已识别 ${uCnt} 条提问、${aCnt} 条 AI 回复`;
        }
      } catch {}
    }
    if(a && !state.busy){
      let changed=false;
      if(a.status==='running'){a.status='ready';changed=true;}
      if(!generationRunning()){
        for(let k=0;k<6;k++){
          if(!a.results[k]){
            const m=findAnswer(aMarker(k));
            if(m?.answer){a.results[k]=m.answer.text;changed=true;}
          }
        }
        if(a.results.every(Boolean)&&a.status!=='complete'){a.status='complete';a.step=6;changed=true;}
      }
      if(changed)a=await saveJob('A',a);
    }
    return {...status(),aJob:a?{status:a.status,step:a.step,operation:a.operation,completed:a.results.filter(Boolean).length,results:a.results.map(Boolean),error:a.lastError||''}:null,bJob:b?{status:b.status,step:b.step,operation:b.operation,completed:b.results.filter(Boolean).length,total:b.total,error:b.lastError||''}:null};
  }
  const handlers={
    PING:()=>({ready:true,conversation:conversation()}),
    GET_STATUS:getState,
    START_A:msg=>startA(msg.operation),
    MANUAL_A_PREPARE:msg=>prepareManualA(msg.index),
    COLLECT_A:collectA,
    EXPORT_A:exportA,
    CLEAR_A:()=>clearJob('A'),
    PREPARE_B:prepareB,
    RUN_B:msg=>runB(msg.operation),
    MANUAL_B_PREPARE:manualBPrepare,
    COLLECT_B:collectB,
    EXPORT_B:exportB,
    CLEAR_B:()=>clearJob('B'),
    EXPORT_C:msg=>exportC(msg.options||{}),
    PAUSE:()=>{state.abort=true;return {pausing:true};}
  };
  if (globalThis.__chatArchiveListener && typeof chrome.runtime.onMessage.removeListener === 'function') {
    try { chrome.runtime.onMessage.removeListener(globalThis.__chatArchiveListener); } catch {}
  }
  const onMsg = (message,sender,respond)=>{
    // Only the extension's own internal popup is allowed to issue privileged commands.
    if(sender.id!==chrome.runtime.id || !new RegExp(`^chrome-extension://${chrome.runtime.id}/popup\\.html(?:[?#]|$)`).test(sender.url||''))return false;
    const rawType = typeof message?.type === 'string' ? message.type.replace(/^V\d+_/, '') : '';
    if(!rawType||!Object.prototype.hasOwnProperty.call(handlers,rawType))return false;
    Promise.resolve().then(()=>handlers[rawType](message)).then(result=>respond({ok:true,data:result})).catch(error=>respond({ok:false,error:String(error?.message||'未知错误').slice(0,600)}));
    return true;
  };
  globalThis.__chatArchiveListener = onMsg;
  chrome.runtime.onMessage.addListener(onMsg);
})();
